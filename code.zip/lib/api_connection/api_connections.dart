class API{
  static const hostConnect = "http://192.168.1.18/api_khelo_prayagraj";
  static const hostConnectUser = "$hostConnect/user";

  //SignUp user
  static const validateEmail = "$hostConnect/user/validate_email.php";
  static const signUp = "$hostConnect/user/signup.php";
  static const login = "$hostConnect/user/login.php";
}
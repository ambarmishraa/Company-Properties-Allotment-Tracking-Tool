import 'package:flutter/material.dart';
import 'package:kheloprayagraj/homescreen/book/bookspage.dart';
import 'package:kheloprayagraj/homescreen/cpu/cpupage.dart';
import 'package:kheloprayagraj/homescreen/flats/flatspage.dart';
import 'package:kheloprayagraj/homescreen/headphone/headphonepage.dart';
import 'package:kheloprayagraj/homescreen/house/housepage.dart';
import 'package:kheloprayagraj/homescreen/laptop/laptoppage.dart';
import 'package:kheloprayagraj/homescreen/mobile%20phone/mobilephonepage.dart';
import 'package:kheloprayagraj/homescreen/monitor/monitorpage.dart';
import 'package:kheloprayagraj/homescreen/tablet/tabletpage.dart';
import 'package:kheloprayagraj/homescreen/vehicles/vehiclepage.dart';

class MARCOS extends StatelessWidget {
  const MARCOS({Key? key}) : super(key: key);

  //This widget is the root of your Application
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MARCOS',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
    );
  }
}

class homescreen extends StatefulWidget {
  const homescreen({Key? key}) : super(key: key);

  @override
  State<homescreen> createState() => _homescreenState();
}

class _homescreenState extends State<homescreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text("Collection"),
        ),
        backgroundColor: Colors.grey,
        body: SingleChildScrollView(
            child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            children: [
              Row(
                children: [
                  Expanded(
                    child: Card(
                      elevation: 5,
                      color: Colors.yellow.shade400,
                      child: Container(
                        height: 150,
                        width: 150,
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => vehiclepage()));
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(top: 20),
                            child: Column(
                              children: [
                                Image.asset(
                                  'assets/Images/vechiles.png',
                                  height: 100,
                                  width: 100,
                                ),
                                const Text("Vehicle",
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold))
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Card(
                      elevation: 5,
                      color: Colors.yellow.shade400,
                      child: Container(
                        height: 150,
                        width: 150,
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => housepage()));
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(top: 20),
                            child: Column(
                              children: [
                                Image.asset(
                                  'assets/Images/Home.png',
                                  height: 100,
                                  width: 100,
                                ),
                                const Text("House",
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold))
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    child: Card(
                      elevation: 5,
                      color: Colors.purpleAccent,
                      child: Container(
                        height: 150,
                        width: 150,
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => bookspage()));
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(top: 20),
                            child: Column(
                              children: [
                                Image.asset(
                                  'assets/Images/Books.png',
                                  height: 100,
                                  width: 100,
                                ),
                                const Text("Books",
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold))
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Card(
                      elevation: 5,
                      color: Colors.purpleAccent,
                      child: Container(
                        height: 150,
                        width: 150,
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => laptoppage()));
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(top: 20),
                            child: Column(
                              children: [
                                Image.asset(
                                  'assets/Images/Laptop.png',
                                  height: 100,
                                  width: 100,
                                ),
                                const Text("Laptop",
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold))
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    child: Card(
                      elevation: 5,
                      color: Colors.greenAccent,
                      child: Container(
                        height: 150,
                        width: 150,
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => flatspage()));
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(top: 20),
                            child: Column(
                              children: [
                                Image.asset(
                                  'assets/Images/flats.png',
                                  height: 100,
                                  width: 100,
                                ),
                                const Text("Flats",
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold))
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Card(
                      elevation: 5,
                      color: Colors.greenAccent,
                      child: Container(
                        height: 150,
                        width: 150,
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => tabletpage()));
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(top: 20),
                            child: Column(
                              children: [
                                Image.asset(
                                  'assets/Images/Tablet.png',
                                  height: 100,
                                  width: 100,
                                ),
                                const Text("Tablet",
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold))
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    child: Card(
                      elevation: 5,
                      color: Colors.redAccent,
                      child: Container(
                        height: 150,
                        width: 150,
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => mobilephonepage()));
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(top: 20),
                            child: Column(
                              children: [
                                Image.asset(
                                  'assets/Images/mobile.png',
                                  height: 100,
                                  width: 100,
                                ),
                                const Text("Mobile Phone",
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold))
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Card(
                      elevation: 5,
                      color: Colors.redAccent,
                      child: Container(
                        height: 150,
                        width: 150,
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => headphonepage()));
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(top: 20),
                            child: Column(
                              children: [
                                Image.asset(
                                  'assets/Images/Headphone.png',
                                  height: 100,
                                  width: 100,
                                ),
                                const Text("Headphone",
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold))
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              Row(
                children: [
                  Expanded(
                    child: Card(
                      elevation: 5,
                      color: Colors.yellow.shade400,
                      child: Container(
                        height: 150,
                        width: 150,
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => monitorpage()));
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(top: 20),
                            child: Column(
                              children: [
                                Image.asset(
                                  'assets/Images/Monitor.png',
                                  height: 100,
                                  width: 100,
                                ),
                                const Text("Monitor",
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold))
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                    child: Card(
                      elevation: 5,
                      color: Colors.yellow.shade400,
                      child: Container(
                        height: 150,
                        width: 150,
                        child: InkWell(
                          onTap: () {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => cpupage()));
                          },
                          child: Padding(
                            padding: const EdgeInsets.only(top: 20),
                            child: Column(
                              children: [
                                Image.asset(
                                  'assets/Images/CPU.png',
                                  height: 100,
                                  width: 100,
                                ),
                                const Text("CPU",
                                    style:
                                        TextStyle(fontWeight: FontWeight.bold))
                              ],
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        )));
  }
}
